<?php
// Query to fetch Canva templates
$args = array(
    'post_type' => 'pl-canva-templates', // Ensure this is your registered custom post type
    'orderby' => 'date', // Order by date
    'order' => 'DESC', // Descending order
    'posts_per_page' => intval($atts['posts_per_page']) // Use the attribute
);

// Handle categories attribute
if (!empty($atts['categories'])) {
  $args['tax_query'] = array(
      array(
          'taxonomy' => 'template_category', // Adjust if your taxonomy is different
          'field'    => 'slug', // Use 'term_id' if using IDs
          'terms'    => explode(',', $atts['categories']) // Split the string into an array
      )
  );
}
$query = new WP_Query($args);
?>

<div class="canva-templates-grid">
  <?php if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post(); 
  $link = get_post_meta(get_the_ID(), 'canva_templates_link_url', true); ?>
    <div class="canva-template-item">
      <?php if (has_post_thumbnail()) :?>
        <a href="<?php echo esc_url($link); ?>">
          <?php echo get_the_post_thumbnail(get_the_ID(), 'full'); // Adjust image size as needed ?>
          
        </a>
        <div class="template-actions">
                <div class="wishlist-icon">
                    <?php echo do_shortcode('[wpe_woo_wl_add_to_wishlists]'); // Add to Wishlist button ?>
                </div>
                <div class="template-link">
                    <a href="<?php echo esc_url($link); ?>">View Template</a>
                </div>
            </div>
      <?php endif; ?>
    </div>
  <?php endwhile; else: ?>
    <p>No Canva templates found.</p>
  <?php endif; ?>
  <?php wp_reset_postdata(); ?>
</div>