<?php
get_header();

require_once(CANVA_TEMPLATES_PLUGIN_PATH . 'views/filter.php');

?>

<div class="custom-container">
<div class="canva-archive-header">
    <h1>Explore Our Canva Templates</h1>
    <p>Find templates for all your needs and filter by category.</p>
</div>
<div class="canva-content-area">
    
<form id="category-filter" class="category-filter">
    <h4 style="margin-bottom:10px;">Apply Filters</h4>
    <?php hierarchical_category_tree(0);?>
    <button id="remove-filters">Remove Filters</button>

</form>
<!-- posts container. while there are posts, it will loop through each post and returns an array for each post containing its taxonomy, then a function is called on the taxonomy array and cat is prefixed with each taxonomy and an array is returned. then that array is imploded on div as its classes. this way a div is created with dynamic classes for each post. -->
<div class="template-container masonry-layout">
    <?php
    if(have_posts()) : while(have_posts()) : the_post();
    $terms = get_the_terms(get_the_ID(), 'template_category');
    $data_class = array_map(function($term) { return 'cat-'. $term->slug;}, (array)$terms);
    $class_list = implode(' ', $data_class);
    $link = get_post_meta(get_the_ID(), 'canva_templates_link_url', true); ?>
    <div class="<?php echo $class_list; ?> template-item"> <!-- Ensure this is the grid item -->
            <a href="<?php echo esc_url($link); ?>">
                <?php the_post_thumbnail('full'); ?>
                <?php the_title('<h4>', '</h4>'); ?>

            </a>
            <div class="template-actions">
                <div class="wishlist-icon">
                <?php echo do_shortcode('[wpe_woo_wl_add_to_wishlists]'); // Add to Wishlist button ?>
                
                </div>
    
            </div>
        </div>
    <?php endwhile;
else: 
    echo 'No templates found';
endif;
?>
</div>
</div>
</div> 
<?php get_footer(); ?>
