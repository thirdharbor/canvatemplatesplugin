<?php
get_header();
?>
<div class="custom-container">
<div class="canva-archive-header">
    <h1 class="archive-title"><?php single_term_title(); ?></h1>
    <p class="archive-description"><?php echo term_description(); ?></p>
</div>
<div class="canva-content-area">

<div class="template-container">
    <?php
    if (have_posts()) : while (have_posts()) : the_post();
        $link = get_post_meta(get_the_ID(), 'canva_templates_link_url', true); ?>
        <div class="template-item"> <!-- Ensure this is the grid item -->
            <a href="<?php echo esc_url($link); ?>">
                <?php the_post_thumbnail('full'); ?>
                <?php the_title('<h4>', '</h4>'); ?>
            </a>
            <div class="template-actions">
                <div class="wishlist-icon">
                    <?php echo do_shortcode('[wpe_woo_wl_add_to_wishlists]'); // Add to Wishlist button ?>
                </div>
            </div>
        </div>
    <?php endwhile; else: 
        echo 'No templates found';
    endif;
    ?>
</div>
</div>
</div>

<?php
get_footer();
?>
