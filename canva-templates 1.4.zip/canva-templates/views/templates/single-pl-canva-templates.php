<?php get_header(); ?>

<div class="canva-template-wrapper">
    <?php
    if (have_posts()) : while (have_posts()) : the_post();
        $template_url = get_post_meta(get_the_ID(), 'canva_templates_link_url', true);
        ?>
        <div class="canva-template-content">
            <div class="canva-template-left">
                <div class="template-title"><?php the_title('<h1>', '</h1>'); ?></div>
                
                <?php if (has_post_thumbnail()) : ?>
                    <div class="canva-template-image">
                        <?php the_post_thumbnail('full'); ?>
                    </div>
                <?php endif; ?>
            </div>

            <div class="canva-template-right">
                <div class="canva-template-description">
                    <?php the_content(); ?>
                </div>
                <a href="<?php echo esc_url($template_url); ?>" class="button use-template-button">Use This Template</a>
            </div>
        </div>
        <?php
    endwhile; endif;
    ?>
</div>


<?php get_footer(); ?>
