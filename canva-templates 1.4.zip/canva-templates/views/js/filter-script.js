document.addEventListener('DOMContentLoaded', function () {
    var checkboxArray = document.querySelectorAll('input[type="checkbox"]');
    checkboxArray.forEach(checkbox => {
        checkbox.addEventListener('change', filterItems);
    });

    document.getElementById('remove-filters').addEventListener('click', function() {
        checkboxArray.forEach(checkbox => {
            checkbox.checked = false; // Uncheck all checkboxes
        });
        filterItems(); // Call the filter function to reset the display
    });

    function filterItems() {
            var checkboxSelectedNodes = document.querySelectorAll('input[type="checkbox"]:checked'); //returning a single node list
            const activeCategoriesArray = Array.from(checkboxSelectedNodes).map(el => 'cat-' + el.value);
            console.log(activeCategoriesArray);
            
            document.querySelectorAll('#template-container a').forEach(link => {
                var isVisible = activeCategoriesArray.length === 0 || activeCategoriesArray.some(cat => link.classList.contains(cat));
                link.style.display = isVisible? 'block' : 'none';
            });
        };
    });
