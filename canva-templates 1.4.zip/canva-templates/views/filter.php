<?php

function hierarchical_category_tree($cat) {
    $next = get_terms(array(
        'taxonomy'   => 'template_category',
        'hide_empty' => false,
        'orderby'    => 'name',
        'order'      => 'ASC',
        'parent'     => $cat
    ));

    if ($next) : 
        echo '<ul>';
        foreach ($next as $cat) {
            echo '<li>';
            echo '<label>';
            echo '<input type="checkbox" name="category_filter[]" value="' . $cat->slug . '" class="cat-' . $cat->slug . '"> ' . $cat->name;
            echo '</label>';
            hierarchical_category_tree($cat->term_id);
            echo '</li>';
        }
        echo '</ul>';
    endif;
}