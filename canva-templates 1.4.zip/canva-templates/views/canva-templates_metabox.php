<?php 
    $link_url = get_post_meta( $post->ID, 'canva_templates_link_url', true );
    //var_dump( $link_url );
?>
<table class="form-table canva-templates-metabox">
    <input type="hidden" name="canva_templates_nonce" value="<?php echo wp_create_nonce( 'canva_templates_nonce' );?>">
    <tr>
        <th>
            <label for= "canva_templates_link_url">Link</label>
        </th>
        <td>
            <input
                type="url"
                name="canva_templates_link_url"
                id="canva_templates_link_url"
                value="<?php echo ( isset( $link_url ) ) ? esc_html( $link_url ) : ''; ?>"
                required
                >
        </td>
    </tr>
</table>