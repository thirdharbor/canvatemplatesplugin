<?php
/*
Plugin Name: Canva Templates
Plugin URI: http://yourwebsite.com
Description: Add canva templates on WordPress to share with your visitors. Your visitors can click the link and go to Canva for editing the template.
Version: 1.3.0
Author: Propellex Labs
Author URI: https://propellex.co
*/



// check if any wordpress constants are defined to ensure the plugin is accessed through wordpress only and not directly. if not, exit. 
if (!defined('ABSPATH')) {
    exit;
}

//check if a class by this name already exists. the new class will only be created when it doesnt already exist. 


if( ! class_exists ('canva-templates')){
    class canva_templates{
        function __construct(){
            $this -> define_constants();
            require_once(CANVA_TEMPLATES_PLUGIN_PATH . 'includes/class-canva-templates-cpt.php');
            $Canva_Templates_Post_Type = new Canva_Template_Post_Type();

            require_once(CANVA_TEMPLATES_PLUGIN_PATH . 'includes/class-canva-templates-shortcode.php');
            $Canva_Templates_Shortcode = new Canva_Template_Shortcode();

            add_filter( 'archive_template', array( $this, 'load_custom_archive_template' ) );
            add_filter( 'single_template', array( $this, 'load_custom_single_template' ) );
            add_filter('template_include', array( $this,'load_custom_taxonomy_template') );
            add_action('wp_enqueue_scripts', array($this, 'enqueue_filter_scripts'));
            add_action('wp_enqueue_scripts', array($this, 'enqueue_canva_template_styles'));


        }
        /**
 * Define plugin constants for easy reference.
 */

        public function define_constants(){
            define( 'CANVA_TEMPLATES_PLUGIN_PATH', plugin_dir_path(__FILE__) ); //retrieves the path of the current file and saves in a constant
            define('CANVA_TEMPLATES_PLUGIN_URL', plugin_dir_url(__FILE__));
            define('CANVA_TEMPLATES_PLUGIN_VERSION', '1.4.0');

        }

        public function enqueue_canva_template_styles() {
            wp_enqueue_style('canva-templates-style', CANVA_TEMPLATES_PLUGIN_URL . 'views/css/canva-single.css', array(), '1.4.0');
            wp_enqueue_style('canva-archive-templates-style', CANVA_TEMPLATES_PLUGIN_URL . 'views/css/canva-archive.css', array(), '1.4.0');
            wp_enqueue_style('canva-shortcode-style', CANVA_TEMPLATES_PLUGIN_URL . 'views/css/canva-shortcode.css', array(), '1.4.0');


        }

        function enqueue_filter_scripts() {
            if (is_post_type_archive('pl-canva-templates')) { // Check if it's the archive page for 'pl-canva-templates'
                wp_enqueue_script('canva-templates-filter-script', CANVA_TEMPLATES_PLUGIN_URL . 'views/js/filter-script.js', array('jquery'), null, true);
            }
        }
        
        public function load_custom_taxonomy_template($tpl) {
            if (is_tax('template_category')) {
                $theme_file = CANVA_TEMPLATES_PLUGIN_PATH . 'views\templates\taxonomy-template_category.php';
                if ($theme_file) {
                    $tpl = $theme_file;
                }
            }
            return $tpl;
        }
        
        

        public function load_custom_archive_template( $tpl ){
            if( current_theme_supports( 'pl-canva-templates' ) ){
                if( is_post_type_archive( 'pl-canva-templates' ) ){
                    $tpl = CANVA_TEMPLATES_PLUGIN_PATH . 'views/templates/archive-pl-canva-templates.php';
                }
            }
            return $tpl;
        }

        public function load_custom_single_template( $tpl ){
            if( current_theme_supports( 'pl-canva-templates' ) ){
                if( is_singular( 'pl-canva-templates' ) ){
                    $tpl = CANVA_TEMPLATES_PLUGIN_PATH . 'views/templates/single-pl-canva-templates.php';
                }
            }
            return $tpl;
        }


        public static function activate (){
            update_option( 'rewrite_rules', '');

        }

        public static function deactivate(){
            flush_rewrite_rules( );
            unregister_post_type( 'pl-canva-templates' );


        }

        public static function uninstall(){

        }


    }
}

//check if class exists. if it does then instantiate the new object. 

if(class_exists('canva_templates')){
    register_activation_hook(__FILE__, array('canva_templates','activate') ); // we pass an array to access a method inside a class
    register_deactivation_hook(__FILE__, array('canva_templates','deactivate') );
    register_uninstall_hook(__FILE__, array('canva_templates','uninstall') );

    $cv = new canva_templates();
}

function custom_plugin_enqueue_masonry_script() {
    wp_enqueue_script('masonry-js', 'https://cdnjs.cloudflare.com/ajax/libs/masonry/4.2.2/masonry.pkgd.min.js', array(), null, true);
    wp_add_inline_script('masonry-js', "
        document.addEventListener('DOMContentLoaded', function () {
            var masonryContainer = document.querySelectorAll('.masonry-layout');
            masonryContainer.forEach(function(container) { 
            new Masonry(container, {
                itemSelector: '.template-item',
                columnWidth: '.template-item',
                percentPosition: true,
                gutter: 15
                });
            });
        });
    ");
}
add_action('wp_enqueue_scripts', 'custom_plugin_enqueue_masonry_script');


