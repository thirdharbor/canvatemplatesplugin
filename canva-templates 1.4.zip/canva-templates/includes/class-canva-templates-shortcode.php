<?php 

if( ! class_exists('Canva_Template_Shortcode')){
    class Canva_Template_Shortcode{
        public function __construct(){
            add_shortcode( 'canva_templates', array( $this, 'canva_templates_shortcode' ) );
        }

        public function canva_templates_shortcode( $atts = array(), $content = null, $tag = '' ){
            ob_start(); // Start buffering

            $atts = array_change_key_case( (array) $atts, CASE_LOWER );

            $atts = shortcode_atts(
                array(
                    'categories' => '', // Comma-separated list of category IDs or slugs
                    'orderby' => 'date', // How to sort the display of posts
                    'posts_per_page' => 5, // Default number of posts
                ),
                $atts,
                $tag
            );

            require(CANVA_TEMPLATES_PLUGIN_PATH . 'views/canva-templates_shortcode.php');


            return ob_get_clean(); // Fetch the buffer contents and clear the buffer




    }
}
}