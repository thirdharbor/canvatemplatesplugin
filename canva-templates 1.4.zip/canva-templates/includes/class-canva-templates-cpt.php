<?php

if(!class_exists('Canva_Template_Post_Type')) {
    class Canva_Template_Post_Type{
        function __construct()
        {
            add_action('init', array($this, 'create_post_type'));
            add_action('init', array($this, 'create_custom_taxonomy'));
            add_action( 'add_meta_boxes', array( $this, 'add_meta_boxes'));
            add_action( 'save_post', array( $this, 'save_post'), 10, 2);
            add_filter( 'manage_pl-canva-templates_posts_columns', array( $this, 'canva_templates_cpt_columns' ) );
            add_action( 'manage_pl-canva-templates_posts_custom_column', array( $this, 'canva_templates_custom_columns'), 10, 2 );
        }

        public function create_post_type(){
            register_post_type(
                'pl-canva-templates',
                array(
                    'label' => 'Canva Templates',
                    'description' => 'Post Type for Canva Templates',
                    'labels' => array(
                        'name' => 'Canva Templates',
                        'singular_name' => 'Canva Template',
                    ),
                    'public' => true,
                    'supports' => array('title', 'editor', 'thumbnail'),
                    'show_in_admin_bar' => true,
                    'show_in_nav_menus' => true,
                    'can_export' => true,
                    'rewrite'     => array('slug' => 'canva-templates'),
                    'has_archive' => true,
                    'publicly_queryable' => true,
                    'menu_icon' => 'dashicons-art',
                    'taxonomies' => array('template_category'),
                )
            );

        }

        public function create_custom_taxonomy() {
            register_taxonomy(
                'template_category',  // Taxonomy key
                'pl-canva-templates', // Array of post types to attach to
                array(
                    'label' => 'Template Categories',
                    'hierarchical' => true,
                    'labels' => array(
                        'name' => 'Template Categories',
                        'singular_name' => 'Template Category',
                        'search_items' => 'Search Template Categories',
                        'all_items' => 'All Template Categories',
                        'edit_item' => 'Edit Template Category',
                        'update_item' => 'Update Template Category',
                        'add_new_item' => 'Add New Template Category',
                        'new_item_name' => 'New Template Category Name',
                        'menu_name' => 'Template Categories',
                    ),
                    'show_ui' => true,
                    'show_in_tag_cloud' => false,
                    'query_var' => true,
                    'rewrite' => array('slug' => 'template-category'),
                )
            );
        }

        public function canva_templates_cpt_columns( $columns ){
            $columns['canva_templates_category'] = esc_html__( 'Category' );
            $columns['canva_templates_link_url'] = esc_html__( 'Link URL' );
            return $columns;
        }

        public function canva_templates_custom_columns( $column, $post_id ){
            switch( $column ){
                case 'canva_templates_category':
                    $terms = get_the_terms($post_id, 'template_category'); 
                    if (!empty($terms) && !is_wp_error($terms)) {
                        $output = array();
                        foreach ($terms as $term) {
                            $output[] = esc_html($term->name);
                        }
                        echo join(', ', $output); // Display all categories as comma-separated values
                    } else {
                        echo esc_html__('None', 'text-domain'); // Display 'None' if no categories
                    }
                    break;
                case 'canva_templates_link_url':
                    echo esc_url( get_post_meta( $post_id, 'canva_templates_link_url', true ) );
                break;                
            }
        }

        public function add_meta_boxes(){
            add_meta_box(
                'pl_canva_templates_meta_box',
                'Template Link',
                array ( $this, 'add_inner_meta_boxes'),
                'pl-canva-templates',
                'normal',
                'high',

            );
        }

//give post parameter in the following function because the metabox has to fetch the value of the key mapped to the post id and display on the form and also send the key and value to be stored in the database against the post id. post is a global wp variable.
        public function add_inner_meta_boxes( $post ){ 
            require_once(CANVA_TEMPLATES_PLUGIN_PATH . 'views/canva-templates_metabox.php');
        }


        public function save_post( $post_id){

            if( isset ( $_POST['canva_templates_nonce'])){
                if (! wp_verify_nonce($_POST['canva_templates_nonce'], 'canva_templates_nonce')){
                    return;
                }
            }

            if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE){
                return;
            }

            if (isset($_POST['post-type']) && $_POST['post-type'] === 'pl-canva-templates'){
                if( ! current_user_can( 'edit_post', $post_id)){
                    return;
                }
            }


            if( isset( $_POST['action']) && $_POST['action'] == 'editpost'){
                $old_link_url = get_post_meta( $post_id, 'canva_templates_link_url', true);
                $new_link_url = $_POST['canva_templates_link_url'];

                if( empty( $new_link_url)){
                    update_post_meta( $post_id, 'canva_templates_link_url', 'Add a link' );
                }else{
                    update_post_meta( $post_id, 'canva_templates_link_url', sanitize_text_field($new_link_url), $old_link_url );
                }

            }
        }

    }
}

